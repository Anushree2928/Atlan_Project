# kafka-cluster-infra
Terraform and Ansible to install a Kafka Cluster

Complete instructions available in my Medium Post:

https://medium.com/@mlombog/deploy-a-kafka-cluster-with-terraform-and-ansible-21bee1ee4fb
